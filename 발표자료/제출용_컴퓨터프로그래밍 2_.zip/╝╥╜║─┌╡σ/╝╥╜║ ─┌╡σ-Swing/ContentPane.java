import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class ContentPane extends JFrame{
	ContentPane(){
		setTitle("ContentPane");
		setSize(500, 500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
// Button_ContentPane
		Container ContentPane = getContentPane();
		ContentPane.setLayout(null); 
		JButton button1 = new JButton("ContentPane");
		button1.setSize(200, 20);
		button1.setLocation(150, 25);
		ContentPane.add(button1);
		
// Button_JFrame		
		setLayout(null);
		JButton button2 = new JButton("JFrame");
		button2.setSize(200, 20);
		button2.setLocation(150, 400);
		add(button2);
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContentPane MainFrame = new ContentPane();
		
	}

}
