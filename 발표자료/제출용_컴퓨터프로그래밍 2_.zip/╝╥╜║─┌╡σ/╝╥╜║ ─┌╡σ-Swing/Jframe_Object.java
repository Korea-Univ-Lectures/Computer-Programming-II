import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Jframe_Object {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame MainFrame = new JFrame();
		MainFrame.setTitle("Jframe_Object");
		MainFrame.setSize(500, 500);
		MainFrame.setVisible(true);
	}
}
