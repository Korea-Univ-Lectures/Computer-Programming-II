import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Jframe_Extend extends JFrame {

	Jframe_Extend(){
		setTitle("JFrame_Extend");
		setSize(200, 200);
		setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Jframe_Extend MainFrame = new Jframe_Extend();
		
	}

}
