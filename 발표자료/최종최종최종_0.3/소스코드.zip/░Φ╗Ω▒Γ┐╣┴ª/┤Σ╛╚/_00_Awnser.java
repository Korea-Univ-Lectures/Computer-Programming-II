package NEW_example;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class _00_Awnser extends JFrame {
	JPanel p1 =new JPanel();
	JTextField t1 =new JTextField("", 15);
	JTextField t2 =new JTextField("", 5);
	
	_00_Awnser (){
		setTitle("Calculator");
		setLayout(new BorderLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(300, 400);
		
		t2.setEnabled(false); //t2�� �۾����⸦ ����
		
		p1.add(t1);
		p1.add(t2);
		
		setLayout(new BorderLayout());
		add(p1, BorderLayout.NORTH);
		
		setVisible(true);
	}
	public static void main(String[] args) {
		new _00_Awnser();
	}
}
