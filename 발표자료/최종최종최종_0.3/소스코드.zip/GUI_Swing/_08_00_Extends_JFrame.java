package GUI_Swing;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class _08_00_Extends_JFrame extends JFrame{

	_08_00_Extends_JFrame(){
		//super("I`m Constructor");
		setTitle("JFrame_Extend");
		setSize(200, 200);
		setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		_08_00_Extends_JFrame MainFrame = new _08_00_Extends_JFrame();
		
	}

}
