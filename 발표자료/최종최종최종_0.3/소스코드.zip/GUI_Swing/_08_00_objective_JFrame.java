package GUI_Swing;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;


public class _08_00_objective_JFrame {

	public static void main(String[] args) {
		JFrame j = new JFrame("I`m Constructor!");
		j.setTitle("I`m JFrame!");
		j.setSize(200,600);
		j.setVisible(true);
	}

}
