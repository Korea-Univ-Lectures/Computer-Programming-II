package painter;

/**
 * 기본 Painter 프로그램에 대한 진입점(entry point)
 */
public class Main {
    public static void main(String[] args) {
        Application application = new Application();
    }
}
